
import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
import seaborn as sns
import ydata_profiling as pf
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.linear_model import LinearRegression,Lasso,Ridge
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor,ExtraTreesRegressor
from sklearn.metrics import r2_score
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
import pickle
import warnings
warnings.filterwarnings('ignore')


boston = load_boston()
data = pd.DataFrame(boston.data)
data.columns = boston.feature_names
data['PRICE'] = boston.target




os.chdir('C:/Users/admin/Desktop/Boston-House-Price-Prediction-Datascience-Project-main')





data.to_csv('Boston House Price Data.csv',index = False)





df = pd.read_csv('Boston House Price Data.csv')





pf.ProfileReport(df)





plt.rcParams['figure.figsize']=(20,15)
sns.heatmap(df.corr(),annot = True, cmap = 'Greens',square = True,cbar = True)
plt.title('Correlation Heat Map')
plt.savefig('Correlation Heat Map.png')
plt.show()





x=df.iloc[:,:-1]
y=df.iloc[:,-1]





def FitModel(x,y,algo_name,algorithm,GridSearchParams,cv):
    np.random.seed(10)
    x_train,x_test,y_train,y_test = train_test_split(x,y,test_size = 0.2,random_state = 99)
    grid = GridSearchCV(estimator = algorithm,param_grid = GridSearchParams,cv = cv,
                     scoring = 'r2',verbose = 0, n_jobs = -1)
    grid_result = grid.fit(x_train,y_train)
    best_params = grid_result.best_params_
    pred = grid_result.predict(x_test)
    pickle.dump(grid_result,open(algo_name,'wb'))
    print('Algorithm Name:\t',algo_name)
    print('Best Params:',best_params)
    print('R2 Score : {}%'.format(100* r2_score(y_test,pred)))             




param = {}
FitModel(x,y,'Linear Regression',LinearRegression(),param,cv=10)



param = {}
FitModel(x,y,'Lasso',Lasso(),param,cv=10)




param={}
FitModel(x,y,'Ridge',Ridge(),param,cv=10)





param = { "max_features":['auto','sqrt'],
          "max_depth":[int(x) for x in np.linspace(6, 45, num = 5)],
          "min_samples_leaf":[1,2,5,10],
          "min_samples_split":[2, 5, 10, 15, 100],
          "min_weight_fraction_leaf":[0.0,0.1,0.2,0.3,0.4,0.5]}

FitModel(x,y,'Decision Tree',DecisionTreeRegressor(),param,cv=10)




param = {'n_estimators':[500,600,800,1000],
         "criterion":["squared_error", "absolute_error", "poisson"]}
FitModel(x,y,'Random Forest',RandomForestRegressor(),param,cv=10)




param = {'n_estimators':[500,600,800,1000],
        'max_features':['auto','sqrt']}
FitModel(x,y,'Extra Trees',ExtraTreesRegressor(),param,cv=10)




param = {"n_estimators":[111,222,333,444]}
FitModel(x,y,'XGBoost',XGBRegressor(),param,cv=10)





param = {}
FitModel(x,y,'CatBoost',CatBoostRegressor(),param,cv=10)





param = {}
FitModel(x,y,'LightGBM',LGBMRegressor(),param,cv=10)





model=pickle.load(open('CatBoost','rb'))



pred1=model.predict(x)
print('R2 Score :{}%'.format(100* r2_score(y,pred1)))




prediction = pd.DataFrame(pred1,columns=['Predicted Price(Approx.)'])
pred_df = pd.concat([df,prediction],axis=1)




pred_df.to_csv('Boston Predicted House Price.csv', index = False)




plt.plot(y,pred1)
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.title('Actual Price vs Predicted Price')
plt.savefig('Actual Price vs Predicted Price.png')
plt.show()

